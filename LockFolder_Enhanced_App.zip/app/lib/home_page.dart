import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'crypto_manager.dart';
import 'storage_index.dart';
import 'widgets/file_item.dart';
import 'package:local_auth/local_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:open_file/open_file.dart';
import 'package:path/path.dart' as p;
import 'dart:math';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final LocalAuthentication auth = LocalAuthentication();
  final FlutterSecureStorage secureStorage = const FlutterSecureStorage();
  late Directory secureDir;
  late File indexFile;
  late StorageIndex index;
  List<String> items = [];
  bool deleteOriginal = false;
  int maxFailed = 5;

  @override
  void initState() {
    super.initState();
    _initDir();
  }

  Future<void> _initDir() async {
    final appDir = await getApplicationDocumentsDirectory();
    secureDir = Directory('\${appDir.path}/secure');
    if (!await secureDir.exists()) await secureDir.create(recursive: true);
    indexFile = File('\${secureDir.path}/index.json.enc');
    index = StorageIndex(indexFile);
    await CryptoManager.ensureKey();
    await index.load();
    _refreshList();
  }

  void _refreshList() {
    final map = index.all();
    setState(() => items = map.entries.map((e) => e.key).toList());
  }

  Future<void> _importFile() async {
    final result = await FilePicker.platform.pickFiles(withData: false);
    if (result == null || result.files.isEmpty) return;
    final path = result.files.single.path;
    if (path == null) return;
    final originalName = result.files.single.name;
    final id = _randomId();
    final outFile = File('\${secureDir.path}/\$id.enc');
    await CryptoManager.encryptFile(File(path), outFile);
    index.add(id, originalName);
    await index.save();
    if (deleteOriginal) await File(path).delete().catchError((_){});
    _refreshList();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Imported & encrypted')));
  }

  String _randomId() => List<int>.generate(8, (_) => Random.secure().nextInt(256)).map((b)=>b.toRadixString(16).padLeft(2,'0')).join();

  Future<bool> _authenticate() async {
    try {
      final canCheck = await auth.canCheckBiometrics || await auth.isDeviceSupported();
      if (canCheck) {
        final didAuth = await auth.authenticate(localizedReason: 'Please authenticate to open file');
        return didAuth;
      }
    } catch (e) {}
    final pin = await secureStorage.read(key: 'pin');
    if (pin == null) {
      return await _setPinDialog();
    } else {
      return await _enterPinDialog(pin);
    }
  }

  Future<bool> _setPinDialog() async {
    final controller = TextEditingController();
    final res = await showDialog<bool>(context: context, builder: (context)=> AlertDialog(
      title: const Text('Set PIN'),
      content: TextField(controller: controller, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: 'Enter new PIN')),
      actions: [
        TextButton(onPressed: ()=> Navigator.of(context).pop(false), child: const Text('Cancel')),
        TextButton(onPressed: () async { if (controller.text.trim().isNotEmpty) { await secureStorage.write(key: 'pin', value: controller.text.trim()); Navigator.of(context).pop(true);} }, child: const Text('Save')),
      ],
    ));
    return res ?? false;
  }

  Future<bool> _enterPinDialog(String correctPin) async {
    final controller = TextEditingController();
    final res = await showDialog<bool>(context: context, builder: (context)=> AlertDialog(
      title: const Text('Enter PIN'),
      content: TextField(controller: controller, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: 'PIN')),
      actions: [
        TextButton(onPressed: ()=> Navigator.of(context).pop(false), child: const Text('Cancel')),
        TextButton(onPressed: ()=> Navigator.of(context).pop(controller.text.trim()==correctPin), child: const Text('OK')),
      ],
    ));
    return res ?? false;
  }

  Future<void> _openEncrypted(String id) async {
    final ok = await _authenticate();
    if (!ok) return;
    final enc = File('\${secureDir.path}/\$id.enc');
    final name = index.originalName(id) ?? id;
    final tmp = File('\${(await getTemporaryDirectory()).path}/\$name');
    await CryptoManager.decryptFile(enc, tmp);
    await OpenFile.open(tmp.path);
    // don't delete tmp immediately so external app can read; OS cleans tmp later
  }

  Future<void> _deleteItem(String id) async {
    final f = File('\${secureDir.path}/\$id.enc');
    if (await f.exists()) await f.delete();
    index.remove(id);
    await index.save();
    _refreshList();
  }

  Widget _settingsTile() {
    return ExpansionTile(title: const Text('Settings'), children: [
      SwitchListTile(title: const Text('Delete original after import'), value: deleteOriginal, onChanged: (v)=> setState(()=> deleteOriginal = v)),
      ListTile(title: const Text('Auto-wipe after failed attempts'), subtitle: Text('Max failed: \$maxFailed')),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('LockFolder Enhanced'), actions: [
        IconButton(icon: const Icon(Icons.refresh), onPressed: _refreshList),
        IconButton(icon: const Icon(Icons.settings), onPressed: (){}),
      ]),
      floatingActionButton: FloatingActionButton(onPressed: _importFile, child: const Icon(Icons.add)),
      body: Column(children: [
        _settingsTile(),
        Expanded(child: ListView.builder(itemCount: items.length, itemBuilder: (c,i){
          final id = items[i];
          final name = index.originalName(id) ?? id;
          return FileItem(filename: name, onOpen: ()=> _openEncrypted(id), onDelete: ()=> _deleteItem(id));
        }))
      ]),
    );
  }
}
