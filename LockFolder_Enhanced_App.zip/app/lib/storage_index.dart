import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'crypto_manager.dart';

class StorageIndex {
  final File indexFile;
  Map<String, String> _map = {};

  StorageIndex(this.indexFile);

  Future<void> load() async {
    if (!await indexFile.exists()) {
      _map = {};
      return;
    }
    final tmp = File('${indexFile.path}.dec');
    await CryptoManager.decryptFile(indexFile, tmp);
    final s = await tmp.readAsString();
    _map = Map<String,String>.from(jsonDecode(s));
    await tmp.delete();
  }

  Future<void> save() async {
    final tmp = File('${indexFile.path}.dec');
    await tmp.writeAsString(jsonEncode(_map));
    await CryptoManager.encryptFile(tmp, indexFile);
    await tmp.delete();
  }

  String? originalName(String id) => _map[id];
  void add(String id, String original) { _map[id] = original; }
  void remove(String id) { _map.remove(id); }
  Map<String,String> all() => Map.from(_map);
}
