import 'package:flutter/material.dart';

class FileItem extends StatelessWidget {
  final String filename;
  final VoidCallback onOpen;
  final VoidCallback onDelete;
  const FileItem({super.key, required this.filename, required this.onOpen, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(filename),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(onPressed: onOpen, icon: const Icon(Icons.open_in_new)),
        IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_forever)),
      ]),
    );
  }
}
