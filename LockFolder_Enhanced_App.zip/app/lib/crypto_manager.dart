import 'dart:io';
import 'dart:math';
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:cryptography/cryptography.dart';

class CryptoManager {
  static const _keyStorageKey = 'lockfolder_key_v2';
  static final _secureStorage = FlutterSecureStorage();
  static final _alg = AesGcm.with256bits();
  static const _nonceLength = 12;

  static Future<void> ensureKey() async {
    final existing = await _secureStorage.read(key: _keyStorageKey);
    if (existing == null) {
      final key = await _alg.newSecretKey();
      final bytes = await key.extractBytes();
      await _secureStorage.write(key: _keyStorageKey, value: base64Encode(bytes));
    }
  }

  static Future<SecretKey> _getKey() async {
    final b64 = await _secureStorage.read(key: _keyStorageKey);
    if (b64 == null) throw Exception('Key not set');
    final bytes = base64Decode(b64);
    return SecretKey(bytes);
  }

  static List<int> _randomBytes(int length) {
    final rnd = Random.secure();
    return List<int>.generate(length, (_) => rnd.nextInt(256));
  }

  static Future<void> encryptFile(File inFile, File outFile) async {
    final key = await _getKey();
    final nonce = _randomBytes(_nonceLength);
    final input = await inFile.readAsBytes();
    final secretBox = await _alg.encrypt(input, secretKey: key, nonce: nonce);
    final bytes = <int>[];
    bytes.addAll(nonce);
    bytes.addAll(secretBox.cipherText);
    bytes.addAll(secretBox.mac.bytes);
    await outFile.writeAsBytes(bytes, flush: true);
  }

  static Future<void> decryptFile(File inFile, File outFile) async {
    final key = await _getKey();
    final all = await inFile.readAsBytes();
    if (all.length < _nonceLength + 16) throw Exception('Invalid file');
    final nonce = all.sublist(0, _nonceLength);
    final mac = all.sublist(all.length - 16);
    final cipherText = all.sublist(_nonceLength, all.length - 16);
    final secretBox = SecretBox(cipherText, nonce: nonce, mac: Mac(mac));
    final plain = await _alg.decrypt(secretBox, secretKey: key);
    await outFile.writeAsBytes(plain, flush: true);
  }
}
