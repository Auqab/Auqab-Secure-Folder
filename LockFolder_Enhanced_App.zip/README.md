# LockFolder Enhanced App

Flutter app that mimics Samsung Secure Folder features.